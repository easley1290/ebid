
<?php $__env->startSection('title', 'Noticias'); ?>
<?php $__env->startSection('nosotros', 'drop-down'); ?>
<?php $__env->startSection('oferta', 'drop-down'); ?>
<?php $__env->startSection('noticia', 'active'); ?>


<?php $__env->startSection('content'); ?>
<section id="hero" class="d-flex align-items-center justify-content-center hero-fondo-home">
  <div class="container" data-aos="fade-up">
      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
          <div class="col-xl-6 col-lg-8">
            <h1>NOTICIAS</h1>
            <h2>de nuestra institucion</h2>
          </div>
      </div>
  </div>
</section>

<section id="services" class="services">
    <div class="container" data-aos="fade-up">
        <div class="row">
            <?php if($noticias != null): ?>
                <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-5">
                        <div class="d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="200">
                            <div class="member" data-aos="fade-up" data-aos-delay="100">
                                <div class="member-img mb-4">
                                    <img src="<?php echo e($noticia->not_imagen); ?>" class="img-fluid" width="100%" alt="">
                                </div>
                                <div class="member-info">
                                    <?php $__currentLoopData = $uacad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ua->ua_id == $noticia->not_ua_id): ?>
                                            <h4><?php echo e($noticia->not_titulo.' _ '.$ua->ua_nombre); ?></h4>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($noticia->not_historia); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-12" style="justify-items: center; text-align:center;" data-aos="zoom-in" data-aos-delay="200">
                    <div class="member" data-aos="fade-up" data-aos-delay="100">
                        <div class="member-info">
                            <h4>Ups!!!! no hay nada que mostrar</h4>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="mt-5">
                <div style="justify-content: space-between; display:inline-block; float:right;"><?php echo e($noticias->onEachSide(10)->links()); ?></div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('ebid-views-portal.componentes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-portal/noticia.blade.php ENDPATH**/ ?>