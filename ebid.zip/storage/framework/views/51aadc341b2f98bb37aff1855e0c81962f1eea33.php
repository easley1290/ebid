
<?php $__env->startSection('title', 'Plantel Docente'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('nosotros', 'active drop-down'); ?>
<?php $__env->startSection('oferta', 'drop-down'); ?>

<section id="hero" class="d-flex align-items-center justify-content-center hero-fondo-home">
  <div class="container" data-aos="fade-up">
        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
            <div class="col-xl-10 col-lg-8">
                <h1><?php echo e($instituciones ->ins_nombree); ?></h1>
                <h2><?php echo e($instituciones ->ins_frasee); ?></h2>
                <h1> PLANTEL DOCENTES</h1>
                <h2>Conozca al equipo de instructores de la Escuela Boliviana de Danza Boliviana.</h2>
            </div>
        </div>
        &nbsp;
        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
            <div class="col-xl-6 col-lg-8">
                <h1></h1>
            </div>
        </div>
  </div>
</section>
<section class="team">
  <div class="container" data-aos="fade-up">
    <div class="section-title alinear-centro">
      <h2></h2>
      <P>CONOCE A NUESTRO EQUIPO DE DOCENTES</P>
    </div>
    <div class="row">
      <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
        <div class="member" data-aos="fade-up" data-aos-delay="100">
          <div class="member-img" style=" height: 80%; 
                                          display: flex;
                                          justify-content: center;
                                          align-items: center;">
            <img src="http://ebid.edu.bo/public<?php echo e($adm->per_foto_personal); ?>" class="img-fluid" alt="" width="100%">
            <div class="social">
              <p style="font-size: 18px;"><?php echo e($adm->name); ?></p>
              <!--a href=""><i class="icofont-facebook"></i></a-->
            </div>
          </div>
          <div class="member-info">
            <h4><?php echo e($adm->name); ?></h4>
            <h4><?php echo e($adm->email); ?></h4>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('ebid-views-portal.componentes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-portal/nosotros/plantel-doc.blade.php ENDPATH**/ ?>