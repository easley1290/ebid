<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title><?php echo $__env->yieldContent('title'); ?> - EBID</title>
    
</head>
<body>
    <header id="header" class="fixed-top">
        <div class="container d-flex align-items-center justify-content-between">
            <a href="/" class="" style="width: 80%;"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="" class="img-fluid"></a>
            <nav class="nav-menu d-none d-lg-block">
                <ul><li class="<?php echo $__env->yieldContent('inicio'); ?>"><a href="/">Inicio</a></li>
                <li class="<?php echo $__env->yieldContent('nosotros'); ?>"><a href="">Nosotros</a>
                    <ul>
                        <li class="<?php echo $__env->yieldContent('MisionVision'); ?>"><a href="<?php echo e(route('MisionVision')); ?>">Mision y vision</a></li>
                        <li class="<?php echo $__env->yieldContent('PlantelAdm'); ?>"><a href="<?php echo e(route('PlantelAdm')); ?>">Rectoria y direccion academica</a></li>
                        <li class="<?php echo $__env->yieldContent('PlantelDoc'); ?>"><a href="<?php echo e(route('PlantelDoc')); ?>">Plantel docente</a></li>
                    </ul>
                </li>
                <li class="<?php echo $__env->yieldContent('oferta'); ?>"><a href="">Oferta académica</a>
                    <ul>
                        <li><a href="<?php echo e(route('perfilProfesional.index')); ?>">Perfil profesional</a></li>
                        <li><a href="<?php echo e(route('procesoAdmision.index')); ?>">Proceso de admision</a></li>
                        <li><a href="<?php echo e(route('malla.index')); ?>">Malla curricular</a></li>
                        <li><a href="<?php echo e(route('inscripcion.index')); ?>">Inscripciones</a></li>
                    </ul>
                </li>
                <li class="<?php echo $__env->yieldContent('galeria'); ?>"><a href="<?php echo e(route('indexGaleria')); ?>">Galeria</a></li>
                <li class="<?php echo $__env->yieldContent('video'); ?>"><a href="<?php echo e(route('indexVideo')); ?>">Videos</a></li>
                <li class="<?php echo $__env->yieldContent('noticia'); ?>"><a href="<?php echo e(route('indexNoticias')); ?>">Noticias</a></li>
                <li class="<?php echo $__env->yieldContent('contactos'); ?>"><a href="<?php echo e(route('indexContactos')); ?>">Contactos</a></li></ul>
            </nav>
            &nbsp;
            <a href="<?php if(Auth::check()): ?> /administracion <?php else: ?> login_ <?php endif; ?>" class="btn-miembro" style="">Eres miembro?</a>
            &nbsp;
            <a href="https://moodle.ebid.edu.bo/moodle/" class="btn-miembro" style="" target='_blank'>Campus Virtual</a>
        </div>
    </header>
    
    <main id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
  
    
    <a href="#" class="back-to-top"><i class="ri-arrow-up-line" style="color: white"></i></a>
    <div id="preloader"></div>
    
</body>
</html>
<?php echo $__env->make('ebid-views-portal.componentes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('ebid-views-portal.componentes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('ebid-views-portal.componentes.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-portal/componentes/main.blade.php ENDPATH**/ ?>