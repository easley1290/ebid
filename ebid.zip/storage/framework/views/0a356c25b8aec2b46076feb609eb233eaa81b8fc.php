
<body class="" id="body">
  <div class="container d-flex flex-column justify-content-between vh-100">
  <div class="row justify-content-center mt-5">
    <div class="col-xl-6 col-lg-6 col-md-12">
      <div class="card">
        <div class="card-header bg-purple">
          <div class="app-brand">
            <a href="/">
              <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="" class="img-fluid">
              <span class="brand-name"><h3>Cambio Contraseña</h3></span>
            </a>
          </div>
        </div>
        <div class="card-body p-5">

        <h5 class="mb-5">Introduzca el email con el que se registró, para enviarle su nueva contraseña</h5>
        
        <form method="POST" action="<?php echo e(route('CambioContraseña')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="form-group col-md-12 mb-4">
                    <input id="email" type="email" class="form-control input-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                    placeholder="ejemplo@usuario.com">

                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <button type="submit" class="btn btn-lg btn-purple btn-block mb-4">Enviar contraseña</button>
            <p>No quieres cambiar tu contraseña?
                <a class="text-purple" href="login_">Volver</a>
            </p>
          
        </form>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>

<?php echo $__env->make('ebid-views-login.componentes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('ebid-views-login.componentes.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-login/contraseña-mail.blade.php ENDPATH**/ ?>