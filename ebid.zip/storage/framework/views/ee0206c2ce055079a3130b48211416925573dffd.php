
<?php $__env->startSection('title', 'Inscripcion'); ?>
<?php $__env->startSection('nosotros', 'drop-down'); ?>
<?php $__env->startSection('oferta', 'drop-down active'); ?>

<?php $__env->startSection('content'); ?>
<section id="hero" class="d-flex align-items-center justify-content-center hero-fondo-home">
  <div class="container" data-aos="fade-up">
      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
          <div class="col-md-6">
            <img src="<?php echo e(asset('assets/img/antiguo.png')); ?>" class="img-fluid" alt="">
            <h2>Estudiante antiguo o miembro de la Institución</h2><br>
            <a href="<?php if(Auth::check()): ?> /administracion <?php else: ?> login_ <?php endif; ?>" class="btn-miembro">INGRESAR AL SISTEMA<i class="ri-arrow-right-s-line"></i></i></a>
          </div>
          <div class="col-md-6">          
            <img src="<?php echo e(asset('assets/img/nuevo.png')); ?>" class="img-fluid" alt="">
            <h2>Estudiante nuevo</h2><br>          
            <a href="register_" class="btn-miembro">REGISTRARME<i class="ri-arrow-right-s-line"></i></i></a>
          </div>

      </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ebid-views-portal.componentes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-portal/oferta-academica/inscripcion.blade.php ENDPATH**/ ?>