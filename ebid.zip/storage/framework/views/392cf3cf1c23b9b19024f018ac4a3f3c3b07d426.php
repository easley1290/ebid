
<?php $__env->startSection('contenido'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <br>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container">							
        <div class="row">
            <div class="row">
                <div class="col-md-12">
                    <div class="card text-white mb-3 bg-primary">
                        <div class="card-header bg-primary" style="font-size: 30px;">INSCRIPCION - PERFIL DE ESTUDIANTE</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card card-default">            
                    <?php if(auth()->user()->per_rol<=3 || auth()->user()->per_id == $datos->per_id): ?>
                    <div class="card-body">
                        <form action="<?php echo e(route('estudiante-nuevo.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="nombre_estudiante">Nombres</label>
                                    <input type="text" class="form-control" 
                                            id="nombre_estudiante" name="nombre_estudiante" 
                                            placeholder="Nombres del estudiante" value="<?php echo e($datos->per_nombres); ?>"
                                            onKeyPress="if(this.value.length==50) return false;" 
                                            tabindex="1" autocomplete="off" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="paterno_estudiante">Apellido Paterno</label>
                                    <input type="text" class="form-control" 
                                            id="paterno_estudiante" name="paterno_estudiante" 
                                            placeholder="Apellido paterno del estudiante" value="<?php echo e($datos->per_paterno); ?>"
                                            onKeyPress="if(this.value.length==50) return false;" 
                                            tabindex="2" autocomplete="off" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="materno_estudiante">Apellido Materno</label>
                                    <input type="text" class="form-control" 
                                            id="materno_estudiante" name="materno_estudiante" 
                                            placeholder="Apellido materno del estudiante" value="<?php echo e($datos->per_materno); ?>"
                                            onKeyPress="if(this.value.length==50) return false;"
                                            tabindex="3" autocomplete="off"  required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-5 mb-3">
                                    <label for="numero_ci_estudiante">Numero de cédula de identidad</label>
                                    <input type="text" class="form-control" 
                                            id="numero_ci_estudiante" name="numero_ci_estudiante" 
                                            placeholder="Numero de C.I. del estudiante" value="<?php echo e($datos->per_num_documentacion); ?>"
                                            onKeyPress="if(this.value.length==20) return false;"
                                            tabindex="4" autocomplete="off"  required>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label for="extension_ci_estudiante" class="form-label">Extension</label>
                                    <select class="form-select" name="extension_ci_estudiante" id="extension_ci_estudiante" required tabindex="5">
                                        <?php if($nombreExt != null): ?>
                                            <option value="<?php echo e($datos->per_subd_extension); ?>" selected><?php echo e($nombreExt->subd_nombre); ?></option>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $extension; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ext): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                                            <option value="<?php echo e($ext->subd_id); ?>"><?php echo e($ext->subd_nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-5 mb-3">
                                    <label for="fec_nacimiento_estudiante">Fecha de nacimiento</label>
                                    <input type="date" class="form-control" 
                                            id="fec_nacimiento_estudiante" tabindex="6" 
                                            value="<?php echo e($datos->per_fecha_nacimiento); ?>" 
                                            name="fec_nacimiento_estudiante" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-5 mb-3">
                                    <label for="numero_telefono_estudiante">Telefono o celular del estudiante</label>
                                    <input type="number" class="form-control" value="<?php echo e($datos->per_telefono); ?>"
                                            id="numero_telefono_estudiante" name="numero_telefono_estudiante" 
                                            placeholder="Numero de telefono del estudiante" 
                                            onKeyPress="if(this.value.length==11) return false;"
                                            tabindex="7" autocomplete="off"  required>
                                </div>
                                <div class="col-md-7 mb-3">
                                    <label for="correo_personal_estudiante">Correo personal del estudiante</label>
                                    <input type="email" class="form-control"  value="<?php echo e($datos->email); ?>"
                                            id="correo_personal_estudiante" name="correo_personal_estudiante" 
                                            placeholder="Servirá de acceso del estudiante hasta que se asigne un institucional"
                                            onKeyPress="if(this.value.length==50) return false;"
                                            tabindex="8" autocomplete="off"  required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6 mb-3">
                                    <label for="domicilio_estudiante">Domicilio del estudiante</label>
                                    <textarea name="domicilio_estudiante" type="text" class="form-control"
                                        id="domicilio_estudiante" autocomplete="off" 
                                        placeholder="Domicilio del estudiante"
                                        onKeyPress="if(this.value.length==100) return false;"
                                        style="height: 100px; resize: none;"
                                        required autocomplete="off"  tabindex="9"><?php echo e($datos->per_domicilio); ?></textarea><br>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="genero_estudiante">Genero del estudiante</label>
                                    <select class="form-select" name="genero_estudiante" id="genero_estudiante" required tabindex="10">
                                        <?php if($nombreGen != null): ?>
                                            <option value="<?php echo e($datos->per_subd_genero); ?>" selected><?php echo e($nombreGen->subd_nombre); ?></option>
                                        <?php else: ?>
                                            <option value="" disabled selected>-- Seleccione el genero --</option>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $genero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                                            <option value="<?php echo e($gen->subd_id); ?>"><?php echo e($gen->subd_nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6 mb-3">
                                    <label for="nombre_tutor">Nombre completo de madre/padre/tutor</label>
                                    <input type="text" class="form-control" value="<?php echo e($datos->est_nombre_tutor); ?>"
                                            id="nombre_tutor" name="nombre_tutor" 
                                            placeholder="Nombre del madre/padre/tutor" 
                                            onKeyPress="if(this.value.length==150) return false;"
                                            tabindex="11" autocomplete="off" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="telefono_tutor">Telefono de referencia de madre/padre/tutor</label>
                                    <input type="number" class="form-control" value="<?php echo e($datos->est_telefono_tutor); ?>"
                                            id="telefono_tutor" name="telefono_tutor" 
                                            placeholder="Numero de telefono de madre/padre/tutor" 
                                            onKeyPress="if(this.value.length==11) return false;"
                                            tabindex="12" autocomplete="off" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="domicilio_tutor">Domicilio de madre/padre/tutor</label>
                                    <textarea name="domicilio_tutor" type="text" class="form-control"
                                        id="domicilio_tutor" autocomplete="off" 
                                        placeholder="Domicilio de madre/padre/tutor"
                                        onKeyPress="if(this.value.length==100) return false;"
                                        style="height: 100px; resize: none;"
                                        required autocomplete="off"  tabindex="13"><?php echo e($datos->est_domicilio_tutor); ?></textarea><br>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="ocupacion_tutor">Ocupacion de madre/padre/tutor</label>
                                    <input type="text" class="form-control" value="<?php echo e($datos->est_ocupacion_tutor); ?>"
                                            id="ocupacion_tutor" name="ocupacion_tutor" 
                                            placeholder="Ocupacion de madre/padre/tutor" 
                                            onKeyPress="if(this.value.length==20) return false;"
                                            tabindex="14" autocomplete="off"  required>
                                </div>
                            </div>
                            <?php if(auth()->user()->per_rol == 1): ?>
                                <div class="form-group row">
                                    <div class="col-md-4 mb-3">
                                        <label for="anio_estudiante">Año en el que cursará el estudiante</label>
                                        <select class="form-select" name="anio_estudiante" id="anio_estudiante" required tabindex="15">
                                            <?php if($nombreSem != null): ?>
                                                <option value="<?php echo e($datos->est_sem_id); ?>" selected><?php echo e($nombreSem->sem_nombre); ?></option>
                                            <?php else: ?>
                                                <option value="" disabled selected>-- Seleccione la gestión --</option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $anio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                                                <option value="<?php echo e($sem->sem_id); ?>"><?php echo e($sem->sem_nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="especialidad">Especialidad del estudiante</label>
                                        <select class="form-select" name="especialidad" id="especialidad" required tabindex="16">
                                            <?php $__currentLoopData = $especialidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                                                <option value="<?php echo e($esp->esp_id); ?>"><?php echo e($esp->esp_nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label for="ua_estudiante">Unidad academica en la que se inscribirá</label>
                                        <select class="form-select" name="ua_estudiante" id="ua_estudiante" required tabindex="17s">
                                            <?php $__currentLoopData = $uacad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                                                <option value="<?php echo e($ua->ua_id); ?>"><?php echo e($ua->ua_nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                            
                                <div class="form-group row">
                                    <div class="col-md-12 mb-3">
                                        <label for="">Seleccione la documentacion y detalles adicionales presentados por el estudiante</label>
                                        <label class="control control-checkbox outlined">Fotocopia legalizada de diploma de bachiller
                                            <?php if($datos->est_bachiller == 'on'): ?>
                                                <input type="checkbox" id="bachiller" name="bachiller" value="<?php echo e($datos->est_bachiller); ?>" checked>
                                                <div class="control-indicator"></div>
                                            <?php else: ?>
                                                <input type="checkbox" id="bachiller" name="bachiller">
                                                <div class="control-indicator"></div>
                                            <?php endif; ?>
                                        </label>
                                        <label class="control control-checkbox outlined">Certificado de nacimiento original actualizado
                                            <?php if($datos->est_cert_nac == 'on'): ?>
                                                <input type="checkbox" id="nacimiento" name="nacimiento" value="<?php echo e($datos->est_cert_nac); ?>" checked>
                                                <div class="control-indicator"></div>
                                            <?php else: ?>
                                                <input type="checkbox" id="nacimiento" name="nacimiento">
                                                <div class="control-indicator"></div>
                                            <?php endif; ?>
                                        </label>
                                        <label class="control control-checkbox outlined">Fotocopia de cedula de identidad del estudiante
                                            <?php if($datos->est_fot_ci == 'on'): ?>
                                                <input type="checkbox" id="ciEst" name="ciEst" value="<?php echo e($datos->est_fot_ci); ?>" checked>
                                                <div class="control-indicator"></div>
                                            <?php else: ?>
                                                <input type="checkbox" id="ciEst" name="ciEst">
                                                <div class="control-indicator"></div>
                                            <?php endif; ?>
                                        </label>
                                        <label class="control control-checkbox outlined">Fotocopia de cedula de identidad del madre/padre/tutor registrado
                                            <?php if($datos->est_fot_tutor == 'on'): ?>
                                                <input type="checkbox" id="ciTutor" name="ciTutor" value="<?php echo e($datos->est_fot_tutor); ?>" checked>
                                                <div class="control-indicator"></div>
                                            <?php else: ?>
                                                <input type="checkbox" id="ciTutor" name="ciTutor">
                                                <div class="control-indicator"></div>
                                            <?php endif; ?>
                                        </label>
                                        <label class="control control-checkbox outlined">Certificaciones de institutos
                                            <?php if($datos->est_certificaciones == 'on'): ?>
                                                <input type="checkbox" id="certificaciones" name="certificaciones" value="<?php echo e($datos->est_certificaciones); ?>" checked>
                                                <div class="control-indicator"></div>
                                            <?php else: ?>
                                                <input type="checkbox" id="certificaciones" name="certificaciones">
                                                <div class="control-indicator"></div>
                                            <?php endif; ?>
                                        </label>
                                        <label class="control control-checkbox outlined">Experiencia previa
                                            <?php if($datos->est_experiencia == 'on'): ?>
                                                <input type="checkbox" id="experiencia" name="experiencia" value="<?php echo e($datos->est_experiencia); ?>" checked>
                                                <div class="control-indicator"></div>
                                            <?php else: ?>
                                                <input type="checkbox" id="experiencia" name="experiencia">
                                                <div class="control-indicator"></div>
                                            <?php endif; ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div style="float: right;">
                                <button type="button" class="btn btn-danger" onclick="javascript:window.close();"><span class="mdi mdi-close"></span>Cancelar</button>
                                <button type="button"  class="btn btn-success" data-bs-toggle="modal" data-bs-target="#confirmar"><span class="mdi mdi-check" ></span>&nbsp;REGISTRAR DATOS</button>
                            </div>

                            <div class="modal fade" id="confirmar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">CONFIRMAR REGISTRO</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                            <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Esta seguro de los datos ingresados?</label>
                                            </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
                                            <button type="submit" class="btn btn-primary" onclick="deshabilitar()" id="conf">CONFIRMAR REGISTRO</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>

<script type="text/javascript">
    function deshabilitar(){
        var boton = document.getElementById('conf');
        setTimeout(function(){
            boton.disabled = true;
        }, 100);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ebid-views-administrador.componentes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-administrador/estudiante/estudiante-nuevo.blade.php ENDPATH**/ ?>