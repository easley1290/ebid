
<?php $__env->startSection('title', 'Galeria'); ?>
<?php $__env->startSection('nosotros', 'drop-down'); ?>
<?php $__env->startSection('oferta', 'drop-down'); ?>
<?php $__env->startSection('galeria', 'active'); ?>

<?php $__env->startSection('content'); ?>
<section id="hero" class="d-flex align-items-center justify-content-center hero-fondo-home">
  <div class="container" data-aos="fade-up">
      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
          <div class="col-xl-6 col-lg-8">
            <h1>GALERIA</h1>
            <h2>Vea nuestras fotografias y vive una experiencia visual de nuestras actividades</h2>
          </div>
      </div>
  </div>
</section>

<section id="portfolio" class="portfolio">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <p>Mira nuestra galeria</p>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
            <?php if($galeria != null): ?>
            <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-5">
                        <div class="portfolio-item">
                            <div class="portfolio-wrap">
                                <img src="<?php echo e($gal->gal_direccion); ?>" class="img-fluid" alt="">
                                <div class="portfolio-info">
                                    <?php $__currentLoopData = $uacad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ua->ua_id == $gal->gal_ua_id): ?>
                                            <h4><?php echo e($gal->gal_titulo.' _ '.$ua->ua_nombre); ?></h4>
                                            <div class="portfolio-links">
                                                <a href="<?php echo e($gal->gal_direccion); ?>" data-gall="portfolioGallery" class="venobox" title="<?php echo e($gal->gal_titulo.' _ '.$ua->ua_nombre); ?>"><i class="bx bx-link"></i></a>
                                            </div>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="col-12" style="justify-items: center; text-align:center;" data-aos="zoom-in" data-aos-delay="200">
                <div class="member" data-aos="fade-up" data-aos-delay="100">
                    <div class="member-info">
                        <h4>Ups!!!! no hay nada que mostrar</h4>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="mt-5">
                <div style="justify-content: space-between; display:inline-block; float:right;"><?php echo e($galeria->onEachSide(10)->links()); ?></div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ebid-views-portal.componentes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-portal/galeria.blade.php ENDPATH**/ ?>