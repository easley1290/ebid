
<?php echo htmlScriptTagJsApi(['lang' => 'es']); ?>

<body class="" id="body">
  <div class="container d-flex flex-column justify-content-between vh-100">
  <div class="row justify-content-center mt-5">
    <div class="col-md-10">
      <div class="card">
        <div class="card-header bg-purple">
          <div class="app-brand">
            <a href="/">
              <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="" class="img-fluid">
              <span class="brand-name"><h3>Inscripción</h3></span>
            </a>
          </div>
        </div>
        <div class="card-body p-5">
          <h4 class="text-dark mb-5">Ingrese los siguientes datos</h4>
          <form method="POST" action="<?php echo e(route('register')); ?>" onsubmit="return validateRecaptcha();">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="form-group col-md-4 mb-4">
                <input id="per_nombres" type="text" 
                      class="form-control input-lg <?php $__errorArgs = ['per_nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="per_nombres" value="<?php echo e(old('per_nombres')); ?>" placeholder="Nombres" 
                      onKeyPress="if(this.value.length==50) return false;"
                      autocomplete="per_nombres" autofocus required>
                <?php $__errorArgs = ['per_nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-4 mb-4">
                <input id="per_paterno" type="text" 
                      class="form-control input-lg <?php $__errorArgs = ['per_paterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="per_paterno" value="<?php echo e(old('per_paterno')); ?>" placeholder="Apellido Paterno" 
                      onKeyPress="if(this.value.length==50) return false;" autocomplete="per_paterno" required>
                <?php $__errorArgs = ['per_paterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-4 mb-4">
                <input id="per_materno" type="text" 
                      class="form-control input-lg <?php $__errorArgs = ['per_materno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="per_materno" value="<?php echo e(old('per_materno')); ?>" placeholder="Apellido materno" 
                      onKeyPress="if(this.value.length==50) return false;" autocomplete="per_materno" required>
                <?php $__errorArgs = ['per_materno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-4 mb-4">
                <input id="per_num_documentacion" type="number" 
                      class="form-control input-lg <?php $__errorArgs = ['per_num_documentacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="per_num_documentacion" value="<?php echo e(old('per_num_documentacion')); ?>" placeholder="Numero de documento" 
                      onKeyPress="if(this.value.length==11) return false;" autocomplete="per_num_documentacion" min="1" required>
                <?php $__errorArgs = ['per_num_documentacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-4 mb-4">
                <input id="per_alfanumerico" type="text" 
                      class="form-control input-lg <?php $__errorArgs = ['per_alfanumerico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="per_alfanumerico" value="<?php echo e(old('per_alfanumerico')); ?>" placeholder="Complemento (Opcional)" 
                      onKeyPress="if(this.value.length==4) return false;" autocomplete="per_alfanumerico">
                <?php $__errorArgs = ['per_alfanumerico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-4 mb-4">
                <select class="form-select form-control" name="per_subd_extension" id="per_subd_extension" required>
                  <option value="" disabled selected>-- Extensión CI --</option>
                  <?php $__currentLoopData = $extension; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ext): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                    <option value="<?php echo e($ext->subd_id); ?>"><?php echo e($ext->subd_nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              
              <!--div class="form-group col-md-6 mb-4">
                <input type="number" class="form-control input-lg" id="materno" aria-describedby="maternoHelp" placeholder="Telefono">
              </div-->

              <div class="form-group col-md-8 mb-4">
                <input id="email" type="email" class="form-control input-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="email" value="<?php echo e(old('email')); ?>" placeholder="Correo personal" 
                      onKeyPress="if(this.value.length==50) return false;"
                      autocomplete="email" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-4 mb-4">
                <input id="per_telefono" type="number" class="form-control input-lg <?php $__errorArgs = ['per_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      name="per_telefono" value="<?php echo e(old('per_telefono')); ?>" placeholder="Celular con Whatsapp"
                      onKeyPress="if(this.value.length==10) return false;" min="1" required>
                <?php $__errorArgs = ['per_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <!--div class="form-group col-md-12 ">
                <input id="password" type="password" class="form-control input-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                name="password" placeholder="Contraseña" autocomplete="new-password" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group col-md-12 ">
                <input id="password-confirm" type="password" class="form-control" 
                name="password_confirmation" placeholder="Confirmar Contraseña" autocomplete="new-password" required>
              </div-->
              
              <div class="col-md-12" aria-label="Verifique el codigo captcha" >
                <div class="col-md-4" style="display: flex; justify-content: center; margin-left: auto; margin-right: auto;"><?php echo htmlFormSnippet(); ?></div>

              </div>

              <div class="form-group row col-md-12">
                <div class="col-md-12 mt-4">
                  <button type="submit" class="btn btn-lg btn-purple btn-block mb-4">Incribirse</button>
                  <p>Ya tienes una cuenta?
                    <a class="text-blue" href="login_">Volver</a>
                  </p>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
<script src='https://www.google.com/recaptcha/api.js?render=onload<?php echo e((isset($lang) ? '&hl='.$lang : '')); ?>'></script>
<script type="text/javascript">
  function validateRecaptcha() {
    var response = grecaptcha.getResponse();
    if (response.length === 0) {
        alert("Debe validar que no es un robot, marcando el captcha");
        return false;
    } else {
        return true;
    }
}
</script>

<?php echo $__env->make('ebid-views-login.componentes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('ebid-views-login.componentes.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-login/register.blade.php ENDPATH**/ ?>