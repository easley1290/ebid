

<?php $__env->startSection('title', 'Malla curricular'); ?>
<?php $__env->startSection('nosotros', 'drop-down'); ?>
<?php $__env->startSection('oferta', 'drop-down active'); ?>

<?php $__env->startSection('content'); ?>
<section id="hero" class="d-flex align-items-center justify-content-center hero-fondo-home">
  <div class="container" data-aos="fade-up">
      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
          <div class="col-xl-6 col-lg-8">
          <h1>MALLA CURRICULAR</h1>
          </div>
      </div>
  </div>
</section>
<section class="inicio">
<div class="container" data-aos="fade-up">
    <div class="row">
      <div class="col-lg-8 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
        <img src="<?php echo e(asset('assets/img/danza.jpg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-4 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right" data-aos-delay="100">
        <h2>CARRERA DE DANZA</h2>
        <?php $__currentLoopData = $institucions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="font-italic">
            <?php echo e($institucion->ins_obj); ?>

        </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="" class="btn-oferta">INSCRIPCION<i class="ri-arrow-right-s-line"></i></i></a>
      </div>
    </div>
</div>
</section>
<div class="container">
    <div class="row">
        <img src="<?php echo e(asset('assets/img/MALLA CURRICULAR.jpg')); ?>" class="img-fluid" alt="">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ebid-views-portal.componentes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebid\resources\views/ebid-views-portal/oferta-academica/malla.blade.php ENDPATH**/ ?>